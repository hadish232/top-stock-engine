# notify.py
# (Full content from assistant message above)
